import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

    http = inject(HttpClient)
  
    private movieUrl = 'https://localhost:7176/api/Movies';

    public getAllMovies():Observable<any[]>{
      return this.http.get<any[]>(`${this.movieUrl}/allMovies`);
    }
  
    public addMovie(data:any):Observable<any>{
      return this.http.post<any>(`${this.movieUrl}/addMovie`,data );
    }
  
    public updateMovie(data:any,id:any):Observable<any[]>{
      return this.http.put<any[]>(`${this.movieUrl}/updateMovie?Id=${id}`,data);
     }
  
     public deleteMovie(id:any):Observable<any[]>{
      return this.http.delete<any[]>(`${this.movieUrl}/deleteMovie?Id=${id}`);
     }
}
