import { HttpClient } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  http = inject(HttpClient)

  private authUrl = 'https://localhost:7176/api/User';

  public registerUser(data:any):Observable<any>{
    return this.http.post<any>(`${this.authUrl}/register`,data );
  }

  public loginUser(data:any):Observable<any>{
    return this.http.post<any>(`${this.authUrl}/login`,data );
  }
  
}
