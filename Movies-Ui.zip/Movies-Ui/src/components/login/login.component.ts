import { Component } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { Router, RouterLink } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule,RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {


  jwtHelperService = new JwtHelperService();

  constructor(private authApi:AuthService,private router:Router,private toast:ToastrService){ }

  loginForm = new FormGroup({
    email : new FormControl('',[Validators.required]),
    password:new FormControl('',[Validators.required]),
  })

  onLogin(){
    var data = {... this.loginForm.value}
    if(this.loginForm.valid){
      this.authApi.loginUser(data).subscribe({
        next: (response: any) => {
          if(response.status == 404){
            this.toast.error(response.message)
          }
          else if(response.status == 401 ){
            this.toast.error(response.message)
          }
          else{
            this.toast.success(response.message)
            sessionStorage.setItem("token",response.token);
            this.loadUser();
          }

          
        },
        error: (error) => {
          this.toast.error(error);
        },
      });
    }
    else{
      this.loginForm.markAllAsTouched();
    }
  }

  loadUser(){
      const token = sessionStorage.getItem("token");
      const userInfo = token != null? this.jwtHelperService.decodeToken(token) : null;
      const data = userInfo ? {
        email:userInfo["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/email"],
        role:userInfo["http://schemas.microsoft.com/ws/2008/06/identity/claims/role"],
        userid:userInfo["http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier"],
        apiKey:userInfo["ApiKey"]
      }:null;
     sessionStorage.setItem('key',data?.apiKey);
     sessionStorage.setItem('role',data?.role);
     if(data?.role=='Admin'){
      this.router.navigate(['/home'])
     }
  }

  get Email() : FormControl{
    return this.loginForm.get('email') as FormControl;
  } 
  get Password() : FormControl{
    return this.loginForm.get('password') as FormControl;
  } 
}
