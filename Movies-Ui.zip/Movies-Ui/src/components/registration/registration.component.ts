import { Component } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { Router, RouterLink } from '@angular/router';
import { Toast, ToastrModule, ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-registration',
  standalone: true,
  imports: [ReactiveFormsModule,RouterLink],
  templateUrl: './registration.component.html',
  styleUrl: './registration.component.css'
})
export class RegistrationComponent {


  constructor(private authApi:AuthService,private router:Router,private toast:ToastrService){}

  regsitrationForm = new FormGroup({
    userType: new FormControl('', [Validators.required]),
    firstName: new FormControl('', [Validators.required,Validators.minLength(2)]),
    lastName: new FormControl('',[Validators.required,Validators.minLength(2)]),
    email: new FormControl("",[Validators.required,Validators.email]),
    password:new FormControl("",[Validators.required,Validators.minLength(8)]),
    cpassword:new FormControl("",[Validators.required])
    })

    onSubmit(){

      if(this.regsitrationForm.value.password !== this.regsitrationForm.value.cpassword){
        this.regsitrationForm.setErrors({invalid:true})
        this.toast.error('passwords do not match');
      }
      if (this.regsitrationForm.valid) {
      const data = {
        userType:this.regsitrationForm.value.userType,
        firstName:this.regsitrationForm.value.firstName,
        lastName:this.regsitrationForm.value.lastName,
        email:this.regsitrationForm.value.email,
        password:this.regsitrationForm.value.password,
      }

      this.authApi.registerUser(data).subscribe({
        next : (response:any)=>{
          if(response.status == 409){
            this.toast.error(response.message);
          }else{
            this.toast.success(response.message);
            this.router.navigate(['/login']);
          }
          
        },
        error : (error)=>{
          console.log(error);
          
        }
      })
    }
    else{
    this.regsitrationForm.markAllAsTouched();
    }
  }


  get FirstName() : FormControl{
    return this.regsitrationForm.get('firstName') as FormControl;
  } 
  get LastName() : FormControl{
    return this.regsitrationForm.get('lastName') as FormControl;
  } 
  get Email() : FormControl{
    return this.regsitrationForm.get('email') as FormControl;
  } 

  get UserType() : FormControl{
    return this.regsitrationForm.get('userType') as FormControl;
  } 

  get Password() : FormControl{
    return this.regsitrationForm.get('password') as FormControl;
  }

}
