import { Component, OnInit } from '@angular/core';
import { MovieService } from '../../services/movie.service';
import { CommonModule } from '@angular/common';
import * as bootstrap from 'bootstrap';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule,ReactiveFormsModule],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent implements OnInit {

  movieList:any;
  selectedFile:File | string = "";
  imageSrc:any;
  updateId:any;

  constructor(private movieService : MovieService,private toast:ToastrService){ }

  getAllMovies(){
    this.movieService.getAllMovies().subscribe((data:any)=>{
      this.movieList = data.movieList;
      
    })
  }
  
  ngOnInit(): void {
    this.getAllMovies();  
  }

  addMovieForm = new FormGroup({
    
    Title:new FormControl('', [Validators.required]),
    ReleaseYear:new FormControl('', [Validators.required]),
    
  })

  editMovieForm = new FormGroup({
    
    Title:new FormControl('', [Validators.required]),
    ReleaseYear:new FormControl('', [Validators.required]),
    Id:new FormControl('')
    
  })


  addMovie(){
    const modal = new bootstrap.Modal(document.getElementById('addModal')!);
    modal.show();
  }

  onDelete(id:any){
    {
      Swal.fire({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#3085d6",
        cancelButtonColor: "#d33",
        confirmButtonText: "Yes, delete it!"
      }).then((result) => {
        if (result.isConfirmed) {
          this.movieService.deleteMovie(id).subscribe((res:any)=>{
            if(res.status==200){
              Swal.fire({
                title: "Deleted!",
                text: "Movie has been deleted.",
                icon: "success"
              });
              this.getAllMovies();
            }
            else{
              Swal.fire({
                title: "Oops!",
                text: "an error occured",
                icon: "error"
              });
            }
          })
        }
      });
    }
  }

  onFileChanged(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
    }
  }

  onSubmit(){
    console.log(this.addMovieForm.value);
    if (this.addMovieForm.valid ) {
          const formData = new FormData();
          Object.keys(this.addMovieForm.value).forEach((key) => {
            formData.append(key, this.addMovieForm.get(key)?.value || "");
          });
          formData.append('Poster', this.selectedFile);
        
          this.movieService.addMovie(formData).subscribe({
            next : (result:any)=>{
            if(result.status == 409){
              this.toast.error(result.message);
            }
            else if(result.status == 200){
              this.toast.success(result.message);
              console.log(formData);
              
            }
            this.addMovieForm.reset();
           
          
            this.getAllMovies();
          },
          error :(error)=>{
            this.toast.error(error.message);
          }
          });   
  }
  else{
    this.addMovieForm.markAllAsTouched();
  }
  }

  onFileEditChanged(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.selectedFile = file;
      const reader = new FileReader();
      reader.onload = () => {
        this.imageSrc = reader.result;
      };
      reader.readAsDataURL(file);
    }
  }

 onEdit(movie:any){
  this.editMovieForm.patchValue({
    Title:movie.title,
    ReleaseYear:movie.releaseYear,
  })

  this.imageSrc = 'https://localhost:7176' + movie.poster;
  this.updateId = movie.id;
  const modal = new bootstrap.Modal(document.getElementById('editModal')!);

  modal.show();
 }

  onUpdate(){
    if(this.editMovieForm.valid){
      const formData = new FormData();
      Object.keys(this.editMovieForm.value).forEach((key) => {
        formData.append(key, this.editMovieForm.get(key)?.value || "");
      });
      
      formData.append('Poster', this.selectedFile);
    
      this.movieService.updateMovie(formData,this.updateId).subscribe((res:any)=>{
        if(res.status==200){  
          this.toast.success('product details updated');
        }
        else{
          this.toast.error('an error occured');
          console.log(res);
          console.log(formData);
          
          
        }
        this.getAllMovies();
      })
    }
  }

  get Title(){
    return this.addMovieForm.get('Title') as FormControl;
  }
  get ReleaseYear(){
    return this.addMovieForm.get('ReleaseYear') as FormControl;
  }

  get editTitle(){
    return this.editMovieForm.get('Title') as FormControl;
  }
  get editReleaseYear(){
    return this.editMovieForm.get('ReleaseYear') as FormControl;
  }
}
