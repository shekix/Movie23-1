﻿using App.core.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Services
{
    public class JwtService : IJwtService
    {
        public string SecretKey { get; set; }

        public int TokenDuration { get; set; }

        public readonly IConfiguration config;

        public JwtService(IConfiguration _config)
        {
            config = _config;
            SecretKey = config.GetSection("jwtConfig").GetSection("Key").Value;
            TokenDuration = int.Parse(config.GetSection("jwtConfig").GetSection("Duration").Value);
        }



        public async Task<string> GenerateToken(string email, int userId, IList<string> roles, string ApiKey)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(SecretKey));

            var signature = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Email, email),
                new Claim(ClaimTypes.NameIdentifier,$"{userId}"),
                new Claim("ApiKey",ApiKey)
            };

            foreach (var role in roles)
            {
                claims.Add(new Claim(ClaimTypes.Role, role));
            }

            var jwtToken = new JwtSecurityToken(
                issuer: "localhost",
                audience: "localhost",
                claims,
                expires: DateTime.Now.AddMinutes(TokenDuration),
                signingCredentials: signature
                );

            return new JwtSecurityTokenHandler().WriteToken(jwtToken);

        }
    }
}
