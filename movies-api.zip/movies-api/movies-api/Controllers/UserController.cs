﻿using App.core.Apps.Movies.command;
using App.core.Apps.Users.command;
using App.core.Models.Movies;
using App.core.Models.Users;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace movies_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<UserController> _logger;

        public UserController(IMediator mediator, ILogger<UserController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }

        [HttpPost("register")]
        public async Task<IActionResult> userRegistration(UserDto dto)
        {
            var result = await _mediator.Send(new CreateUserCommand { UserDto = dto });
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest("an error occured");
        }

        [HttpPost("login")]
        public async Task<IActionResult> userLogin(LoginDto dto)
        {
            var result = await _mediator.Send(new LoginUserCommand { LoginDto = dto });
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest("an error occured");
        }
    }
}
