﻿using App.core.Apps.Movies.command;
using App.core.Apps.Movies.query;
using App.core.Models.Movies;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace movies_api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MoviesController : ControllerBase
    {
        private readonly IMediator _mediator;
        private readonly ILogger<MoviesController> _logger;
        public MoviesController(IMediator mediator, ILogger<MoviesController> logger)
        {
            _mediator = mediator;
            _logger = logger;
        }
        [Authorize(Roles = "Admin")]
        [HttpPost("addMovie")]
        public async Task<IActionResult> addMovie([FromForm] MovieDto dto)
        {
            var result = await _mediator.Send(new CreateMovieCommand { MovieDto = dto });
            if(result != null)
            {
                return Ok(result);
            }
            return BadRequest("an error occured");
        }

        [Authorize(Roles = "Admin")]
        [HttpPut("updateMovie")]
        public async Task<IActionResult> updateMovie([FromForm] UpdateMovieDto dto , int Id)
        {
            var result = await _mediator.Send(new UpdateMovieCommand {Id= Id, MovieDto = dto });
            if(result != null)
            {
                return Ok(result);
            }
            return BadRequest("an error occured");
        
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("deleteMovie")]
        public async Task<IActionResult> deleteMovie(int Id)
        {
            var result = await _mediator.Send(new DeleteMovieCommand { Id = Id });
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest("an error occured");
        }

        [HttpGet("allMovies")]
        public async Task<IActionResult> getAllMovies()
        {
            var result = await _mediator.Send(new GetMoviesQuery { });
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest(result);
        }

        [HttpGet("movieSearch")]
        public async Task<IActionResult> getMoviesBySearch(string s,string apiKey)
        {
            var result = await _mediator.Send(new GetMovieBySearchQuery { s = s });
            if (result != null)
            {
                return Ok(result);
            }
            return BadRequest($"Could not find {s}");
        }
    }
}
