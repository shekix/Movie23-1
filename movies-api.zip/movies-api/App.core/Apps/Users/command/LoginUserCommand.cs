﻿using App.core.Interfaces;
using App.core.Models.Users;
using Domain.Users;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Apps.Users.command
{
    public class LoginUserCommand : IRequest<object>
    {
        public LoginDto LoginDto { get; set; }
    }

    public class LoginUserCommandHandler : IRequestHandler<LoginUserCommand, object> 
    {
        private readonly IAppDbContext _appDbContext;
        private readonly IJwtService _jwtService;

        public LoginUserCommandHandler(IAppDbContext appDbContext , IJwtService jwtService)
        {
            _appDbContext = appDbContext;
            _jwtService = jwtService;
        }

        public async Task<object> Handle(LoginUserCommand command, CancellationToken cancellationToken)
        {
            var model = command.LoginDto;
            var exitingUser = await _appDbContext.Set<User>().Where(x=>x.Email == model.Email).FirstOrDefaultAsync();
            if (exitingUser == null)
            {
                return new
                {
                    status = 404,
                    message = "User with this Email does not exists"
                };
            }
            if(VerifyPassword(model.Password,exitingUser.Password))
            {
                var role = exitingUser.UserType == 1 ? "Admin" : "User";
                var jwtToken = await Task.FromResult(_jwtService.GenerateToken(exitingUser.Email, exitingUser.Id, new List<string> { role },exitingUser.ApiKey));
                return new
                { 
                    status = 200,
                    message = "successfull",
                    token = jwtToken.Result
                };
            }
            return new 
            { 
                status = 401,
                message = "invalid password",
            };

        }


        public bool VerifyPassword(string plainTextPassword, string hashedPassword)
        {
            // Verify the password
            return BCrypt.Net.BCrypt.Verify(plainTextPassword, hashedPassword);
        }

    }

}
