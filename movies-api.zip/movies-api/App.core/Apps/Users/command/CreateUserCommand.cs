﻿using App.core.Apps.Movies.command;
using App.core.Interfaces;
using App.core.Models.Users;
using AutoMapper;
using Domain.Movies;
using Domain.Users;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Apps.Users.command
{
    public class CreateUserCommand : IRequest<object>
    {
        public UserDto UserDto { get; set; }
    }
    public class CreateUserCommandHandler : IRequestHandler<CreateUserCommand, object> 
    {
        private readonly IAppDbContext _appDbContext;
        private readonly IMapper _mapper;
        public CreateUserCommandHandler(IAppDbContext appDbContext, IMapper mapper)
        {
            _appDbContext = appDbContext;
            _mapper = mapper;
        }

        public async Task<object> Handle(CreateUserCommand command, CancellationToken cancellationToken)
        {
            var model = command.UserDto;
            var existingUser = await _appDbContext.Set<User>().Where(x => x.Email == model.Email).FirstOrDefaultAsync();
            if (existingUser != null)
            {
                return new
                {
                    status = 409,
                    message = "The user with this email already exists"
                };
            }
            Guid newGuid = Guid.NewGuid();
            var user = _mapper.Map<User>(model);
            user.ApiKey = newGuid.ToString();
            user.Password = HashPassword(model.Password);
            await _appDbContext.Set<User>().AddAsync(user);
            await _appDbContext.SaveChangesAsync();
            return new
            {
                status = 200,
                message = "Account successfully created"
            };
        }


        public static string HashPassword(string plainTextPassword)
        {
            // Hash the password with a salt
            return BCrypt.Net.BCrypt.HashPassword(plainTextPassword);
        }



    }

}
