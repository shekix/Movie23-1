﻿using App.core.Interfaces;
using App.core.Models.Movies;
using AutoMapper;
using Domain.Movies;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Apps.Movies.command
{
    public class UpdateMovieCommand : IRequest<object>
    {
        public int Id { get; set; }
        public UpdateMovieDto MovieDto { get; set; }
    }

    public class UpdateMovieCommandHandler : IRequestHandler<UpdateMovieCommand, object>
    {
        private readonly IAppDbContext _appDbContext;
        private readonly IMapper _mapper;
        public UpdateMovieCommandHandler(IAppDbContext appDbContext, IMapper mapper)
        {
            _appDbContext = appDbContext;
            _mapper = mapper;
        }

        public async Task<object> Handle(UpdateMovieCommand command, CancellationToken cancellationToken)
        {
            var existingMovieId = command.Id;
            var existingMovie = _appDbContext.Set<Movie>().Where(x=>x.Id == existingMovieId).FirstOrDefault();
            if (existingMovie == null)
            {
                return new
                {
                    status = 404,
                    message = "Movie Not Found"
                };
            }
            var model = command.MovieDto;

            string posterPath = null;
            if(model.Poster != null)
            {
                posterPath = ImagePath(model.Poster);
            }
            else
            {
                posterPath = existingMovie.Poster;
            }

            var movie =  _mapper.Map(model, existingMovie);
            existingMovie.Poster = posterPath;
           
            existingMovie.IsDeleted = false;
            _appDbContext.Set<Movie>().Update(movie);
            await _appDbContext.SaveChangesAsync();

            return new { 
                status = 200,
                message = "Movie Updated"
            };


        }


        public string ImagePath(IFormFile image)
        {
            if (image != null)
            {

                var folderPath = Path.Combine("wwwroot", "posters");

                // Ensure the directory exists
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Generate a unique file name
                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(image.FileName)}";
                var filePath = Path.Combine(folderPath, fileName);

                // Save the file 
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream);
                }

                // Return relative path
                return $"/posters/{fileName}";


            }
            return null;
        }
    }

}
