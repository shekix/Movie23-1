﻿using App.core.Interfaces;
using App.core.Models.Movies;
using AutoMapper;
using Domain.Movies;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Apps.Movies.command
{
    public class CreateMovieCommand : IRequest<object>
    {
        public MovieDto MovieDto { get; set; }
    }

    public class CreateMovieCommandHandler : IRequestHandler<CreateMovieCommand, object> 
    {
        private readonly IAppDbContext _appDbContext;
        private readonly IMapper _mapper;
        public CreateMovieCommandHandler(IAppDbContext appDbContext,IMapper mapper)
        {
            _appDbContext = appDbContext;
            _mapper = mapper;
        }

        public async Task<object> Handle(CreateMovieCommand command,CancellationToken cancellationToken)
        {
            var model = command.MovieDto;
            var existingMovie = await _appDbContext.Set<Movie>().Where(x=>x.Title == model.Title && x.ReleaseYear == model.ReleaseYear).FirstOrDefaultAsync();
            if (existingMovie != null)
            {
                return new {
                    status = 409,
                    message = "The movie already exists"
                };

            }
            string posterPath = ImagePath(model.Poster!);
            var movie = _mapper.Map<Movie>(model);
            movie.Poster = posterPath;
            movie.IsDeleted = false;
            await _appDbContext.Set<Movie>().AddAsync(movie);
            await _appDbContext.SaveChangesAsync();
            return new
            {
                status = 200,
                message = "Movie successfully added"
            };
        }



        public string ImagePath(IFormFile image)
        {
            if (image != null)
            {

                var folderPath = Path.Combine("wwwroot", "posters");

                // Ensure the directory exists
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }

                // Generate a unique file name
                var fileName = $"{Guid.NewGuid()}{Path.GetExtension(image.FileName)}";
                var filePath = Path.Combine(folderPath, fileName);

                // Save the file 
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream); 
                }

                // Return relative path
                return $"/posters/{fileName}";


            }
            return $"/posters/default.jpg";
        }

    }

}
