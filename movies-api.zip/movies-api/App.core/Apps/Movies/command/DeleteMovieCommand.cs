﻿using App.core.Interfaces;
using Domain.Movies;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Apps.Movies.command
{
    public class DeleteMovieCommand : IRequest<object>
    {
        public int Id { get; set; }
    }

    public class DeleteMovieCommandHandler : IRequestHandler<DeleteMovieCommand, object> 
    {
        private readonly IAppDbContext _appDbContext;

        public DeleteMovieCommandHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<object> Handle(DeleteMovieCommand command, CancellationToken cancellationToken)
        {
            var existingMovieId = command.Id;
            var existingMovie = _appDbContext.Set<Movie>().Where(x => x.Id == existingMovieId).FirstOrDefault();

            if (existingMovie == null)
            {
                return new
                {
                    status = 404,
                    message = "Movie Not Found"
                };
            }

            existingMovie.IsDeleted = true;
            _appDbContext.Set<Movie>().Update(existingMovie);
            await _appDbContext.SaveChangesAsync();

            return new
            {
                status = 200,
                message = "Movie Deleted"
            };
        }
    }

}
