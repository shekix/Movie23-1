﻿using App.core.Apps.Users.command;
using App.core.Interfaces;
using Domain.Movies;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Apps.Movies.query
{
    public class GetMoviesQuery : IRequest<object>
    {

    }

    public class GetMoviesQueryHandler : IRequestHandler<GetMoviesQuery, object> 
    {
        private readonly IAppDbContext _appDbContext;
        public GetMoviesQueryHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<object> Handle(GetMoviesQuery request , CancellationToken cancellationToken)
        {
            var movies = await _appDbContext.Set<Movie>().Where(x => x.IsDeleted == false).ToListAsync();
            if(movies == null)
            {
                return new {
                status = 404,
                message = "no movies found"
                };

            }

            return new { 
            status = 200,
            movieList = movies
            };

        }

        
    }

}
