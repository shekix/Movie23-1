﻿using App.core.Interfaces;
using Domain.Movies;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Apps.Movies.query
{
    public class GetMovieBySearchQuery : IRequest<object>
    {
     public string s { get; set; }
    }

    public class GetMovieBySearchQueryHandler : IRequestHandler<GetMovieBySearchQuery, object> 
    { 
        private readonly IAppDbContext _appDbContext;
        public GetMovieBySearchQueryHandler(IAppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<object> Handle(GetMovieBySearchQuery query, CancellationToken cancellationToken)
        {
            var movies = _appDbContext.Set<Movie>().Where(m => m.IsDeleted == false);

            if (!string.IsNullOrWhiteSpace(query.s))
            {
                movies = movies.Where(x => x.Title != null && EF.Functions.Like(x.Title, $"%{query.s}%"));
            }

            var searchResult = await movies.ToListAsync(cancellationToken);
            return new
            {
                status = 200,
                message = "Filtered Movies",
                filteredMovie = searchResult
            };
        }
    }

}
