﻿using App.core.Models.Movies;
using Domain.Users;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Models.Users
{
    public class UserDto
    {
        public int UserType { get; set; }
        public required string FirstName { get; set; }
        public required string LastName { get; set; }
        public required string Email { get; set; }
        public required string Password { get; set; }
    }

    public class UserDtoValidator : AbstractValidator<UserDto>
    {

        public UserDtoValidator()
        {
            RuleFor(x => x.UserType).InclusiveBetween(1, 2).WithMessage("role can either be 1(Admin) or 2(User)").NotEmpty().WithMessage("Cannot be empty");
            RuleFor(x => x.FirstName).Length(2, 20).WithMessage("must have minimum 3 characters or maximum 20 characters").NotEmpty().WithMessage("Cannot be empty");
            RuleFor(x => x.LastName).Length(2, 20).WithMessage("must have minimum 3 characters or maximum 20 characters").NotEmpty().WithMessage("Cannot be empty");
            RuleFor(x => x.Email).EmailAddress().WithMessage("must be a valid Email Address").NotEmpty().WithMessage("Email cannot be empty");
            RuleFor(x => x.Password).Length(8, 12).WithMessage("must have minimum 8 characters or maximum 12 characters").NotEmpty().WithMessage("Cannot be empty");
        }

    }
}
