﻿using FluentValidation;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core.Models.Movies
{
    public class UpdateMovieDto
    {
        public required string Title { get; set; }
        public required string ReleaseYear { get; set; }
        public IFormFile? Poster { get; set; }

    }

    public class UpdateMovieDtoValidator : AbstractValidator<UpdateMovieDto>
    {

        public UpdateMovieDtoValidator()
        {
            RuleFor(x => x.Title).Length(1, 30).NotEmpty();
            RuleFor(x => x.ReleaseYear).Length(4).Must(x => int.TryParse(x, out var val) && val > 1900 && val < 2025).NotEmpty().WithMessage("must be a 4 digit number");
        }

    }
}

