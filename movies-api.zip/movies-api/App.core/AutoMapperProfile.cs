﻿using App.core.Models.Movies;
using App.core.Models.Users;
using AutoMapper;
using Domain.Movies;
using Domain.Users;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace App.core
{
    public class AutoMapperProfile : Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<MovieDto, Movie>();
            CreateMap<UpdateMovieDto, Movie>();
            CreateMap<UserDto,User>();
                
        }
    }
}
